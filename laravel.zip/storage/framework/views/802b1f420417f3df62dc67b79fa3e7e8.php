<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Form Result</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">
</head>
<body>
    <div class="container mt-5">
        <h1>Form Submission Result</h1>
        <div class="card">
            <div class="card-body">
                <p><strong>Product:</strong> <?php echo e($data['product']); ?></p>
                <p><strong>Skin Types:</strong> <?php echo e(implode(', ', $data['skinTypes'])); ?></p>
                <p><strong>Skin Problems:</strong> <?php echo e(implode(', ', $data['skinProblems'])); ?></p>
                <p><strong>Effects:</strong> <?php echo e(implode(', ', $data['effects'])); ?></p>
            </div>
        </div>
    </div>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\SDT\resources\views/result.blade.php ENDPATH**/ ?>